---
name: Institutional Trust Modernism
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#444651'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#002d48'
  on-tertiary: '#ffffff'
  tertiary-container: '#004469'
  on-tertiary-container: '#56b3f9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-audit:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.01em
  code-audit-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system embodies an authoritative, institutional aesthetic tailored for academic registries, government compliance, and corporate governance. It projects uncompromising security, legal certainty, and bureaucratic efficiency while maintaining the fluid legibility of a premier enterprise utility. 

The aesthetic is anchored in **Corporate / Modern** principles with structured document hierarchy:
- **Atmosphere:** Rigorous, clean, and unassailable. Avoid decorative clutter or whimsical animations.
- **Visual Weight:** Grounded surfaces framed by surgical 1px micro-borders, confident typography, and deliberate white space that evokes high-caliber legal paper and digital seal verification.
- **Audience:** Rectors, legal counsels, compliance officers, and executive signatories requiring instantaneous clarity over document lifecycle, audit logs, and cryptographic validity.

## Colors
The palette leverages a high-contrast institutional hierarchy anchored by deep indigos and crisp slate neutrals.

### Palette Architecture
- **Primary Canvas Background:** `#F8FAFC` (Slate-50) creates an anti-glare, non-fatiguing digital desk workspace.
- **Surface Elevation:** Pure White `#FFFFFF` for data cards, modals, document viewers, and panels.
- **Primary Ink & Action (`#1E3A8A` / `#1E40AF`):** Represents formal institutional authority. Used for primary CTAs, active navigation states, verified certificates, and primary branding tokens.
- **Secondary Slate (`#0F172A`):** Anchors headers, primary document titles, and critical action points.
- **Neutral Boundary Scales:**
  - Borders: `#E2E8F0` (Slate-200) for standard card and panel division.
  - Subtle Dividers: `#F1F5F9` (Slate-100) for table rows and secondary separations.
  - Subtext & Muted Labels: `#64748B` (Slate-500) and `#94A3B8` (Slate-400).
  - Body Text: `#334155` (Slate-700) ensures AAA compliance across surfaces.

### Semantic Status Tokens
- **Disetujui (Approved / Valid Seal):** Background `#ECFDF5`, Border `#A7F3D0`, Text `#065F46`, Indicator `#059669`.
- **Menunggu (Pending Signature / Review):** Background `#FFFBEB`, Border `#FDE68A`, Text `#92400E`, Indicator `#D97706`.
- **Ditolak (Rejected / Revoked):** Background `#FFF1F2`, Border `#FECDD3`, Text `#9F1239`, Indicator `#E11D48`.
- **Diproses / TIK (Processing / Cryptographic Engine):** Background `#EFF6FF`, Border `#BFDBFE`, Text `#1E40AF`, Indicator `#2563EB`.

## Typography
Typography balances immediate legal legibility with technical precision.

- **Primary Typeface (Plus Jakarta Sans):** Selected for its crisp geometric terminals, open counters, and formal clarity at dense information densities. It keeps dense audit dashboards breathable.
- **Monospace Technical Typeface (JetBrains Mono):** Mandated for all SHA-256 hash digests, certificate serial numbers, timestamp trails, IP logs, and cryptographic document watermarks.
- **Hierarchy Rules:** Large numbers (dashboard KPI counters) use `display-lg` with `fontWeight: 700` paired directly with `label-sm` uppercase descriptors. Document tracking titles use `headline-sm` with tabular alignment.

## Layout & Spacing
The layout follows a fluid-hybrid desktop layout engine optimized for institutional widescreen operations and split-pane document evaluation.

### Layout Mechanics
- **App Shell Framework:** Fixed-width 260px left sidebar navigation paired with a persistent 64px global application utility bar.
- **Main Canvas:** Fluid grid with max bounds capped at 1600px for ultrawide panels, maintaining 2rem (`margin`) lateral safe zones.
- **Split-Screen Workspace:** The PDF Preview and Signatory Action view adopts a strict 60/40 structural column split, anchoring the document canvas left and metadata/signature tooling right.
- **Data Densities:** Table rows enforce a strict 48px standard row height for executive overviews and a 40px compact row height for high-volume audit logs, utilizing `space-sm` vertical padding and `space-md` horizontal cell clearance.

## Elevation & Depth
Depth in the design system is engineered through structural containment rather than dramatic shadow projection, emphasizing administrative stability and legal precision.

### Elevation Hierarchy
- **Level 0 (Desk Canvas):** `#F8FAFC` flat surface.
- **Level 1 (Card & Module Foundation):** Pure White `#FFFFFF` with a crisp `1px solid #E2E8F0` border and `box-shadow: 0 1px 2px 0 rgba(15, 23, 42, 0.05)` (`shadow-sm`).
- **Level 2 (Dropdowns, Popovers, & Context Actions):** Pure White `#FFFFFF` backed by `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)` with a `1px solid #CBD5E1` boundary.
- **Level 3 (Signature Canvas & Verification Modals):** Pure White `#FFFFFF` backed by `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.04)` over a semi-translucent backdrop veil (`#0F172A` at 45% opacity).
- **Watermark & Security Layer:** Floating security indicators sit inside a dedicated sub-layer using `backdrop-filter: blur(4px)` with 80% surface opacity and micro-hairline borders (`rgba(255, 255, 255, 0.4)`).

## Shapes
The design system leverages **Level 2 (Rounded)** shape semantics to balance modern digital software standards with the upright geometry demanded by institutional governance.

- **Primary Cards & Layout Panels:** Enforce `rounded-xl` (1.5rem / 24px) for outer card perimeters and workspace viewports, providing a contained, refined frame.
- **Standard Controls (Inputs, Buttons, Dropdowns):** Enforce `0.5rem` (8px) radius to maintain crisp alignment along tabular grid axes.
- **Status Chips & Pills:** Absolute pill radii (`9999px`) to immediately distinguish categorical meta-tags from actionable buttons or form fields.
- **Document Thumbnails:** `0.375rem` (6px) radius paired with an inset hairline border to simulate physical sheet stacks.

## Components

### Buttons & Interactive Controls
- **Primary Action (e.g., 'Tandatangani Sekarang'):** Solid `#1E3A8A` background, white text, 8px radius, height 40px, font `label-md`. Hover state: `#1E40AF`. Active: `#172554`. Focus: 2px ring offset with `#3B82F6`.
- **Secondary Action (e.g., 'Unduh Bukti Audit'):** Pure white background with `1px solid #CBD5E1`, text `#334155`. Hover: `#F8FAFC` with border `#94A3B8`.
- **Destructive Action (e.g., 'Tolak Dokumen'):** `#FFF1F2` surface, `#E11D48` border and text. Hover: `#FEE2E2` with `#9F1239` text.

### Status Pills & Identity Badges
- Constructed with `9999px` full-pill radius, 4px horizontal padding, 2px vertical padding.
- Employs an internal 6px centered status dot paired with `label-sm` uppercase text.
- Must display strictly defined institutional statuses: *Disetujui*, *Menunggu Verifikasi*, *Ditolak*, and *Diproses*.

### Data Tables & Document Registry
- Headers: `#F8FAFC` background, text uppercase `label-sm` in `#64748B`, bottom border `1px solid #E2E8F0`.
- Body Rows: White `#FFFFFF`, subtle hover background `#F8FAFC`, separated by `1px solid #F1F5F9`.
- Integrated Columns: Document name with MIME icon, document ID using `code-audit`, status pill, and signatory progression avatar stacks.

### Form Inputs & Signature Placement Targets
- Field Elements: 40px height, background `#FFFFFF`, border `1px solid #CBD5E1`, placeholder `#94A3B8`, text `#0F172A`. Focus state uses `#1E40AF` border with `0 0 0 1px #1E40AF`.
- Signature Dropzones: Inset dashed border (`2px dashed #94A3B8`) on `#F8FAFC` surface, transitioning to solid `#1E3A8A` and `#EFF6FF` background when valid signing credentials hover.

### Security Watermark & Audit Trail Elements
- **Verification Stamp Container:** Outlined container bearing institutional seal metadata, including SHA-256 certificate string, digital signer serial, and timestamp formatted strictly in `code-audit` font token.
- **Audit Sidebar Timeline:** Continuous vertical connector line (`2px solid #E2E8F0`) with 12px circular state nodes matching semantic status colors.